var avatarElement = document.querySelector('.avatar img')
var emailElement = document.querySelector('#email')
var nomeElement = document.querySelector('#nome')

axios
        .get('https://api.github.com/users/jaisllam',{
            headrs:{Authorization:'token cbf0c0d65afb10c210a8c02f8d11acbaff30b996'}
                }),

        .then(function(response){
            console.log(response.data);
        })
function renderInfo(response){
    console.log(response.avatar_url)
    avatarElement.setAttribute('src',''+response.avatar_url +'')

    emailElement.innerText = ''+response.email+''
    nome.innerText = ''+response.name+''


}